<?php
class Position extends ActiveRecord\Model
{
	static $belongs_to;
};
?>